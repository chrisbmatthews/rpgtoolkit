/*************************
 CPakFile.h
 Definition for pak file
 *************************/


#ifndef _CPAKFILE_H_
#define _CPAKFILE_H_

#include "FileHeaders.h"
#include "CHuffman.h"

class CPakFile
{
public:
	CPakFile(char* pstrFilename, bool bReadOnly);
	~CPakFile();
	void Add(char* pstrFileToAdd, char* pstrSaveAs);
	void Extract(char* pstrFileToExtract, char* pstrSaveAs);
	void Delete(char* pstrFileToDelete);
	void Defrag(char* pstrSaveAs);
	void AddFromList(char* pstrListName);
	void AddCompressed(char* pstrFileToAdd, char* pstrSaveAs, int nCompType);
	int FATSize();
	char* GetFATName(int nFATPos);
	bool FileExist(char* pstrFileToCheck);
	char* GetFileName() { return m_pstrFilename; }

private:
	char* ReadString();

private:
	char*		m_pstrFilename;
	FILE*		m_file;

	FSHead*	m_pFSH;		//file system header.
	FAT*		m_pFAT;		//file allocation table

	CHuffman*	m_Huff;	//compression class.

};

#endif /* _CPAKFILE_H_
/* end of file */