/*********************************
 FileHeaders.h
 defines headers used int he pak file.
 *********************************/

#ifndef _FILEHEADERS_H_
#define _FILEHEADERS_H_


//What I mean by pseudo-absolute:
//These files are intended to be able to be tacked onto the end of other files.
//Therefore, p-absolute means that a byte position of, say 12, is only physically
//at location 12 if the header is sitting at position 0.  If the header is at position
//180, then p-absolute positon 12 is actually at physical position 192.


/************************************
 A standard file looks like this:

 FSHead (512 bytes)

	. . .

 SEGHead (16 bytes)
 SEGFileInfo	(512 bytes)		(only exists if this is a beginning segment (ie, nAbsolutePrev = -1)
 SEGFilename (variable, and only if at a *beginning* segment (ie, nAbsolutePrev = -1)
 -SEGMENT DATA- (variable)
 SEGFoot

	. . .

 SEGHead		(no following FILEInfo or file name if nAbsolutePrev != -1)
 -SEGMENT DATA- (variable)
 SEGFoot

	. . .

 FATHead (16 bytes)
 FAT		(variable)
 FSFoot (32 bytes)
 ************************************/

/************************************************************************************************/

/***************************
 File header (512 bytes)
 ***************************/
typedef struct 
{
	char			strTag[5];						//file tag ('FS10')
	int				nAbsoluteBeginning;		//pseudo-absolute location of this header (probably 0)
	int				nDataSize;						//total size of all data, in bytes
	int				nDeletedSize;					//total size of all deleted data, in bytes.
	int				nAbsoluteFAT;					//pseudo-absolute position of File Allocation Table
	int				nAbsoluteHole;				//pseudo-absolute position of first hole (-1 = none)
	int				nCopyright;						//copyright year (ie 2001)
	char			strAuthor[64];				//author string
	char			strDescription[256];	//description
	char			cEncryption;					//type of encryuption used 0=none
	char			cCompression;					//type of compression used 0=none
	char			strPassword[8];				//password (byte-shifted encrypted)
	char			reserved[148];				//unused.  sizeof(FSHead) == 512 bytes (364 w/o reserved)
} FSHeadStruct;


class FSHead
{
public:
	FSHead(FILE* f);
	void Write();
	void Read();
	void SetFilePos(int fp);

public:
	FSHeadStruct	m_fsh;

private:
	FILE*			m_file;									//file pointer
	int				m_nFilePos;						//where does it live in the file?
};


/************************************************************************************************/


/***************************
 Segment Header
 ***************************/
typedef struct
{
	int				nAbsolutePrev;				//pseudo-absolute position of previous segment for this file (-1 = none)
	char			cDeleted;							//deleted flag (0=not deleted, 1=deleted)
	int				nSegSize;							//size of this segment, in bytes (excluding this header and the following filename define (if one exists)).
	int				nFileSize;						//total size of file (all file segments added together).
	char			reserved[3];					//unused. sizeof(FSFoor) == 16 bytes (13 w/o reserved)
} SEGHead;


/************************************************************************************************/


/***************************
 File Info Header
 Only exists after a SEGHead 
 if this is the beginning of
 the file (ie, nAbsolutePrev 
 == -1)
 ***************************/
typedef struct
{
	int				nCopyright;							//file copyright
	char			strAuthor[64];					//file author
	char			strDescription[256];		//file description.
	char			cEncryption;						//type of encryption used 0=none
	char			cCompression;						//type of compression used 0=none
	char			strPassword[8];					//password (byte-shifted encrypted)
	char			reserved[178];					//unused. sizeof(SEGFileInfo) == 512 bytes (334 w/o reserved)
} SEGFileInfo;


/************************************************************************************************/


/***************************
 SEGFilename
 Filename of segment.  Only 
 appears following a 
 SEGFileInfo, which only occurs 
 if SEGHead is at the beginning
 of the file (ie, nAbsolutePrev
 == -1
 ***************************/
typedef struct
{
	char*			pstrFilename;						//filename, null-terminated.  variable length.
} SEGFilename;


/************************************************************************************************/


/***************************
 SEGFoot
 Appears at the end of a segment.
 ***************************/
typedef struct
{
	int				nAbsoluteNext;					//pseudo-absolute position of next segment for this file (-1 indicates EOF)
	char			reserved[28];						//unused. sizeof(SEGFoot) == 32 bytes (4 w/o reserved)
} SEGFoot;


/************************************************************************************************/


/***************************
 File footer (512 bytes)
 ***************************/
typedef struct
{
	char			strTag[5];						//file tag ('FS10')
	int				nAbsoluteBeginning;		//pseudo-absolute position of header.
	char			reserved[23];					//unused.  sizeof(FSFoot) == 32 bytes, (9 w/o reserved)
} FSFoot;


/***************************
 FATHead
 This is not intended to 
 be a joke.
 The header for the File 
 Allocation Table.
 ***************************/
typedef struct
{
	char			cType;								//type of FAT 0=default (the only one I have invented thus far)
	int				nEntryCount;					//number of entries in the FAT.
	char			reserved[7];					//unused. sizeof(FATHead) == 16 bytes (5 w/o reserved)
} FATHead;

/***************************
 FAT
 File Allocation Table.
 Variable sized.
 ***************************/
class FAT
{
public:
	FAT(FILE *f);
	~FAT();
	void SetFilePos(int fp);
	int Read();
	void Write();
	void Add(char* pstrFilename, int nFilePos);
	int Find(char* pstrFilename);
	void Delete(char* pstrFileToDelete);
	char* GetFilename(int num);
	int NumFiles() { return m_FATHead.nEntryCount; }

private:
	char* ReadString();

public:
	FSFoot	m_Foot;								//file footer.

private:
	FILE*		m_file;
	int			m_nFilePos;						//where does it live in the file?
	int			m_nArraySize;					//size of FAT arrays
	//these go in the file:
	FATHead	m_FATHead;						//FAT header.
	int*		m_pnFileLocations;		//array of ints-- the locations of all the files.
	char**	m_ppstrFilenames;			//array of strings (filenames)
};



/*************************************************************************/


#endif	/* _FILEHEADERS_H_ */
/*end of file*/