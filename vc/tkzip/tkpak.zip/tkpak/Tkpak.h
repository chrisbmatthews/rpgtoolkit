///////////////////////////////////////////////////////
//
// MODULE: tkgfx.h
//
// PURPOSE: dll for toolkit graphics engine (header)
//
// Copyright 2000 by Christopher B. Matthews
//
///////////////////////////////////////////////////////

/*
 * Includes
 */
#include "resource.h"		// main symbols


///////////////////////////////////////////////
//Exported functions...
int APIENTRY PAKTest();

int APIENTRY PAKAdd(char* pstrToAdd, char* pstrAddAs, char* pstrPakFile);

int APIENTRY PAKAddCompressed(char* pstrToAdd, char* pstrAddAs, char* pstrPakFile);

int APIENTRY PAKExtract(char* pstrToExt, char* pstrSaveAs, char* pstrPakFile);

int APIENTRY PAKGetFileCount(char* pstrPakFile);

int APIENTRY PAKFileExist(char* pstrFileToCheck, char* pstrPakFile);

/* end of file */