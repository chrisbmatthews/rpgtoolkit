// pak.cpp : Defines the entry point for the console application.
//

/****************************************
 PACKFILE SYSTEM
 Copyright 2001 By Christopher Matthews
 ****************************************/

#include "stdafx.h"
#include "tkpak.h"
#include "CPakFile.h"
#include "CHuffman.h"
#include "helper.h"
#include <stdlib.h>

///////////////////////////////////
// EXE Entry point...
int main(int argc, char *argv[])
{
	cout << "RPG Toolkit Pak System (version 2001.01)" << endl;
	cout << "Copyright 2001 By Christopher B. Matthews" << endl << endl;
	if (argc == 4)
	{
		if (strcmpi(argv[1], "-c") == 0)
		{
			//compress
			CPakFile* cp = new CPakFile(argv[3], false);
			if (cp)
			{
				AddFiles(cp, argv[2], "", true, COMP_ZLIB);
				delete cp;
				cp = NULL;
				return 0;
			}
		}
		if (strcmpi(argv[1], "-d") == 0)
		{
			//decompress
			CPakFile* cp = new CPakFile(argv[2], false);
			if (cp)
			{
				ExtractFiles(cp, argv[3]);
				delete cp;
				cp = NULL;
				return 0;
			}
		}
	}
	if (argc == 3)
	{
		if (strcmpi(argv[1], "-d") == 0)
		{
			//decompress
			CPakFile* cp = new CPakFile(argv[2], false);
			if (cp)
			{
				ExtractFiles(cp, "");
				delete cp;
				cp = NULL;
				return 0;
			}
		}
	}
	cout << "Usage: " << endl;
	cout << "Compress:   tkpak -c filefilter destfile.tpk" << endl;
	cout << " example:   tkpak -c *.* test.tpk   (compresses all files into test.tpk)" << endl << endl;
	cout << "Decompress: tkpak -d sourcefile.tpk [destpath\\]" << endl;
	cout << " example:   tkpak -d test.tpk  (extracts into current dir)" << endl;
	return 0;
}

///////////////////////////////////
// DLL Entry point...
int APIENTRY PAKTest()
{
	return 1;
}

int APIENTRY PAKAdd(char* pstrToAdd, char* pstrAddAs, char* pstrPakFile)
{
	//open pakfile...
	CPakFile cp(pstrPakFile, false);
	cp.Add(pstrToAdd, pstrAddAs);
	return 1;
}


int APIENTRY PAKAddCompressed(char* pstrToAdd, char* pstrAddAs, char* pstrPakFile, int nCompType)
{
	//open pakfile...
	
	//FILE* f = fopen ("c:\\dump.txt", "at");
	//fputs(pstrToAdd, f);
	//fclose (f);

	CPakFile* cp = new CPakFile(pstrPakFile, false);
	if (cp)
	{
		cp->AddCompressed(pstrToAdd, pstrAddAs, nCompType);
		delete cp;
	}
	return 1;
}


int APIENTRY PAKExtract(char* pstrToExt, char* pstrSaveAs, char* pstrPakFile)
{
	//open pakfile...
	CPakFile cp(pstrPakFile, true);
	cp.Extract(pstrToExt, pstrSaveAs);
	return 1;
}


int APIENTRY PAKGetFileCount(char* pstrPakFile)
{
	//obtain the number of files in the pakfile...
	CPakFile cp(pstrPakFile, true);
	return cp.FATSize();
}


int APIENTRY PAKFileExist(char* pstrFileToCheck, char* pstrPakFile)
{
	//determine if a file exists in the pakfile...
	CPakFile cp(pstrPakFile, true);
	bool found = cp.FileExist(pstrFileToCheck);
	if (found)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

