/*********************************
 FileHeaders.cpp
	implementation of header classes
 *********************************/

#include "stdafx.h"
#include "FileHeaders.h"

/***************************
 CLASS FSHead
 File header (512 bytes)
 ***************************/

//constructor:
//inits to defaults...
FSHead::FSHead(FILE* f) 
{
	strcpy(m_fsh.strTag, "FS10");
	m_fsh.nAbsoluteBeginning = 0;
	m_fsh.nDataSize = 0;
	m_fsh.nDeletedSize = 0;
	m_fsh.nAbsoluteFAT = sizeof(FSHeadStruct);	//FAT is right after head.
	m_fsh.nAbsoluteHole = -1;			//no deleted segments yet
	m_fsh.nCopyright = 2001;			//whatever, man
	strcpy(m_fsh.strAuthor, "");
	strcpy(m_fsh.strDescription, "");
	m_fsh.cEncryption = 0;				//no encryption
	m_fsh.cCompression = 0;				//no compression
	strcpy(m_fsh.strPassword, "");

	m_file = f;
}


/*****************************
 FSHead::Write()

 write the header to the file

 *****************************/
void FSHead::Write() 
{
	fseek(m_file, m_nFilePos, SEEK_SET);
	fwrite(&m_fsh, sizeof(FSHeadStruct), 1, m_file);
}


/*****************************
 FSHead::Read(nBeginning)

 read the header from the file

 nBeginning is position to read 
 from.

 *****************************/
void FSHead::Read() 
{
	fseek(m_file, m_nFilePos, SEEK_SET);
	fread(&m_fsh, sizeof(FSHeadStruct), 1, m_file);
}


/*****************************
 FSHead::SetFilePos(fp)

	Set the new abosolute positon
	in the file for the FSHead

 *****************************/
void FSHead::SetFilePos(int fp)
{
	m_nFilePos = fp;
	m_fsh.nAbsoluteBeginning = fp;
}


/**********************************************************************************************/

/***************************
 CLASS FAT
	variable sized
 ***************************/

//c-tor.  requires an opened file.
FAT::FAT(FILE *f)
{
	m_file = f;
	m_nFilePos = 0;
	m_nArraySize = 0;
	m_pnFileLocations = NULL;
	m_ppstrFilenames = NULL;
	m_FATHead.cType = 0;		//default FAT type.
	m_FATHead.nEntryCount = 0;
	
	strcpy(m_Foot.strTag, "FS10");
	m_Foot.nAbsoluteBeginning = 0;

}

FAT::~FAT()
{
	delete [] m_pnFileLocations;
	for (int i=0; i<m_nArraySize; i++)
	{
		delete [] m_ppstrFilenames[i];
	}
	delete [] m_ppstrFilenames;
}


/*****************************
 FAT::SetFilePos(fp)

	Set the new abosolute positon
	in the file for the FAT

 *****************************/
void FAT::SetFilePos(int fp)
{
	m_nFilePos = fp;
}


/*****************************
 FAT::Read()

	Reads the FAT from the file.

 *****************************/
int FAT::Read()
{
	fseek(m_file, m_nFilePos, SEEK_SET);

	//read header...
	fread(&m_FATHead, sizeof(FATHead), 1, m_file);

	//allocate space for the FAT...
	delete [] m_pnFileLocations;
	delete [] m_ppstrFilenames;
	m_nArraySize = m_FATHead.nEntryCount*2;
	m_pnFileLocations = new int[m_nArraySize];
	m_ppstrFilenames = new char*[m_nArraySize];
	for (int i=0; i<m_nArraySize; i++)
	{
		m_ppstrFilenames[i] = NULL;
	}

	//now read each entry...
	for (int j=0; j<m_FATHead.nEntryCount; j++)
	{
		char* in = ReadString();
		m_ppstrFilenames[j] = new char[strlen(in)+1];
		strcpy(m_ppstrFilenames[j], in);
		fread(&m_pnFileLocations[j], sizeof(int), 1, m_file);
	}

	//now read file foot...
	fread(&m_Foot, sizeof(FSFoot), 1, m_file);

	return m_FATHead.nEntryCount;
}


/*****************************
 FAT::Write()

	Write the FAT to the file.

 *****************************/
void FAT::Write()
{
	fseek(m_file, m_nFilePos, SEEK_SET);

	//write header...
	fwrite(&m_FATHead, sizeof(FATHead), 1, m_file);

	//now write each entry...
	for (int j=0; j<m_FATHead.nEntryCount; j++)
	{
		fwrite(m_ppstrFilenames[j], sizeof(char), strlen(m_ppstrFilenames[j])+1, m_file);
		fwrite(&m_pnFileLocations[j], sizeof(int), 1, m_file);
	}

	fwrite(&m_Foot, sizeof(FSFoot), 1, m_file);
}


/*****************************
 FAT::Add()

	Add an entry to the FAT

	pstrFilename- filename to add
	nFilePos - pseudo-absolute 
	location of the file's header

 *****************************/
void FAT::Add(char* pstrFilename, int nFilePos)
{
	int i=0;
	//find an empty space in the FAT...
	for (i=0; i<m_FATHead.nEntryCount; i++)
	{
		if (strcmp(m_ppstrFilenames[i], "") == 0)
		{
			//found an empty space!
			delete [] m_ppstrFilenames[i];
			m_ppstrFilenames[i] = new char[strlen(pstrFilename)+1];
			strcpy(m_ppstrFilenames[i], pstrFilename);
			m_pnFileLocations[i] = nFilePos;
			return;
		}
	}

	//didn't find in FAT.  We will have to increase FAT size...
	if (m_FATHead.nEntryCount < m_nArraySize) 
	{
		//there is room in the Array!
		m_FATHead.nEntryCount++;
		i = m_FATHead.nEntryCount - 1;
		delete [] m_ppstrFilenames[i];
		m_ppstrFilenames[i] = new char[strlen(pstrFilename)+1];
		strcpy(m_ppstrFilenames[i], pstrFilename);
		m_pnFileLocations[i] = nFilePos;
		return;
	}
	else
	{
		//we have to increase the size of the arrays!
		if (m_nArraySize == 0)
			m_nArraySize = 1000;
		m_nArraySize *=2;
		char** pTempFiles = new char*[m_nArraySize];
		int* pTempLocs = new int[m_nArraySize];
		for (i=0; i<m_nArraySize; i++)
		{
			pTempFiles[i] = NULL;
			pTempLocs[i] = 0;
		}
		for (i=0; i<m_FATHead.nEntryCount; i++)
		{
			pTempFiles[i] = new char[strlen(m_ppstrFilenames[i]+2)];
			strcpy(pTempFiles[i], m_ppstrFilenames[i]);
			pTempLocs[i] = m_pnFileLocations[i];

			delete [] m_ppstrFilenames[i];
		}
		delete [] m_ppstrFilenames;
		delete [] m_pnFileLocations;

		m_ppstrFilenames = pTempFiles;
		m_pnFileLocations = pTempLocs;

		m_FATHead.nEntryCount++;
		i = m_FATHead.nEntryCount - 1;
		delete [] m_ppstrFilenames[i];
		m_ppstrFilenames[i] = new char[strlen(pstrFilename)+1];
		strcpy(m_ppstrFilenames[i], pstrFilename);
		m_pnFileLocations[i] = nFilePos;
		return;

	}

}


/*****************************
 FAT::Find()

	Finds a filename in the FAT
	and returns it's file 
	position.  Returns -1 if
	not found!

 *****************************/
int FAT::Find(char* pstrFilename)
{
	int i=0;
	//find the file...
	for (i=0; i<m_FATHead.nEntryCount; i++)
	{
		if (strcmpi(m_ppstrFilenames[i], pstrFilename) == 0)
		{
			//found it!
			return m_pnFileLocations[i];
		}
	}

	//not found.
	return -1;
}


/*****************************
 FAT::Delete()

	Remove a file from the FAT list

 *****************************/
void FAT::Delete(char* pstrFileToDelete)
{
	int i=0;
	//find the file...
	for (i=0; i<m_FATHead.nEntryCount; i++)
	{
		if (strcmpi(m_ppstrFilenames[i], pstrFileToDelete) == 0)
		{
			//found it!
			delete [] m_ppstrFilenames[i];
			for (int j=i; j<m_FATHead.nEntryCount-1; j++) 
			{
				m_ppstrFilenames[j] = new char[strlen(m_ppstrFilenames[j+1])+1];
				strcpy(m_ppstrFilenames[j], m_ppstrFilenames[j+1]);
				m_pnFileLocations[j] = m_pnFileLocations[j+1];
			}
			strcpy(m_ppstrFilenames[m_FATHead.nEntryCount-1], "");
			m_FATHead.nEntryCount--;
			return;
		}
	}
}


/*****************************
 FAT::GetFilename()

	obtain the num-th filename
	from the FAT

 *****************************/
char* FAT::GetFilename(int num)
{
	return m_ppstrFilenames[num];
}


/*****************************
 FAT::ReadString()

	Reads a null-terminated string 
	from the file.

 *****************************/
char* FAT::ReadString()
{
	char* strIn = new char[2048];
	char part;
	int n=0;
	bool bDone = false;
	while (!bDone)
	{
		fread(&part, sizeof(char), 1, m_file);
		if (part == 0)
		{
			//end of string encountered!
			strIn[n] = part;
			//int l = strlen(strIn);
			//pstrCopyTo = new char[l+1];
			//strcpy(pstrCopyTo, strIn);
			bDone = true;
		}
		else
		{
			strIn[n] = part;
			n++;
		}
	}
	return strIn;
}

/*end of file*/