/*************************
 CHuffman.h
 Definition for huffman 
 compressor/decompressor
 *************************/

#ifndef _CHUFFMAN_H_
#define _CHUFFMAN_H_

#define COMP_NONE -1
#define COMP_HUFF 0
#define COMP_ZLIB 1

//node for huffman tree
class CHuffNode
{
public:
	CHuffNode(char cASCII, int nCount, CHuffNode* p, CHuffNode* o, CHuffNode* z);
	~CHuffNode();
	int size();
	
public:
	//the links...
	CHuffNode* parent;
	CHuffNode* one;
	CHuffNode* zero;

	unsigned char m_cElement;
	int m_nCount;
};


//actual huffman class...
class CHuffman
{
public:
	CHuffman();
	~CHuffman();
	void Compress(char* pstrInFile, char* pstrOutFile);
	void Decompress(char* pstrInFile, char* pstrOutFile);
	void SetCompType(int nCompType);

private:
	void CountChars(char* pstrInFile);
	void BuildTree();
	void CombineSmallest();
	void FillEncodingTable();
	int	 CalcCompressedSize();
	void WriteCompressedFile(char* pstrInFile, char *pstrOutFile);
	void WriteEncoded(unsigned char part, FILE* fout);
	void CloseCompressionStream(FILE* fout);
	unsigned char BitsToByte(char* theByte);
	int power(int base, int exp);
	void WriteDecoded(unsigned char part, FILE* fout);
	void ByteToBits(unsigned char part, char* theByte);
	int AttemptTreeDecode();

private:
	int m_nASCIICount[256];		//count of each ASCII char.
	CHuffNode* m_NodeArray[256];	//node array.
	int m_nNodeCount;					//size of node array.
	CHuffNode* m_LeafArray[256];	//array of leafs
	int m_nLeafCount;					//number of leafs.
	//encoding table...
	char m_EncodingTable[256][256];
	//temporary encoding string for WriteEncoded method...
	char m_strEncode[102048];
	//holds the number of bytes written thus far in the decompression...
	int m_nBytesWritten;
	int m_nUncompSize;		//uncompressed size.
	int m_nCompType;			//compression type 0=huffman, 1=zlib

};

#endif