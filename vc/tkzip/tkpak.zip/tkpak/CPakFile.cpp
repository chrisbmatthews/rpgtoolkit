/*************************
 CPakFile.h
 implementation
 *************************/

#include "stdafx.h"
#include "CPakFile.h"
#include <stdlib.h>

//c-tor-- specify the file you wish to operate on!
CPakFile::CPakFile(char* pstrFilename, bool bReadOnly)
{
	bool bCreateFile = false;

	m_pstrFilename = new char[strlen(pstrFilename)+1];
	strcpy(m_pstrFilename, pstrFilename);
	if (bReadOnly) 
	{
		m_file = fopen(m_pstrFilename, "rb");
	}
	else
	{
		m_file = fopen(m_pstrFilename, "r+b");
		if (!m_file)
		{
			bCreateFile = true;	//we are creating a new file here.
			m_file = fopen(m_pstrFilename, "w+b");
		}
	}

	//create file system header...
	m_pFSH = new FSHead(m_file);
	//create FAT...
	m_pFAT = new FAT(m_file);

	if (bCreateFile)
	{
		m_pFSH->Write();
		m_pFAT->SetFilePos(m_pFSH->m_fsh.nAbsoluteFAT);
		m_pFAT->Write();
	}
	else
	{
		//a file already exists there-- but is it a valid
		//pakfile?
		//if it is, great.
		//if it's not, we're gonna tack a pakfile onto the tail
		//of the existing file.

		//first read tail...
		fseek(m_file, 0, SEEK_END);
		int nsize = ftell(m_file);
		fseek(m_file, nsize - sizeof(FSFoot), SEEK_SET);
		FSFoot fsf;
		fread(&fsf, 1, sizeof(FSFoot), m_file);
		if (strcmp(fsf.strTag, "FS10")==0)
		{
			//it's a valid pakfile!
			fseek(m_file, fsf.nAbsoluteBeginning, SEEK_SET);
			m_pFSH->SetFilePos(fsf.nAbsoluteBeginning);
			m_pFSH->Read();
			m_pFAT->SetFilePos(m_pFSH->m_fsh.nAbsoluteFAT);
			m_pFAT->Read();
		}
		else
		{
			//it's some other type of file.
			//we'll put a pakfile onto the end of it!
			m_pFSH->SetFilePos(nsize);
			m_pFSH->m_fsh.nAbsoluteBeginning = nsize;
			m_pFSH->m_fsh.nAbsoluteFAT = nsize + sizeof(FSHeadStruct);
			m_pFSH->Write();
			m_pFAT->SetFilePos(m_pFSH->m_fsh.nAbsoluteFAT);
			m_pFAT->m_Foot.nAbsoluteBeginning = nsize;
			m_pFAT->Write();
		}

	}

	m_Huff = new CHuffman();

}


//d-tor
CPakFile::~CPakFile()
{
	if (m_file)
	{
		fclose(m_file);
	}
	delete [] m_pstrFilename;
	delete m_pFSH;
	delete m_Huff;
}


/*************************
 FATSize

 returns number of entries 
 in FAT
 *************************/
int CPakFile::FATSize()
{
	m_pFAT->SetFilePos(m_pFSH->m_fsh.nAbsoluteFAT);
	m_pFAT->Read();
	return m_pFAT->NumFiles();
}

/*************************
 GetFATName

	get ith filename in FAT
 *************************/
char* CPakFile::GetFATName(int nFATPos)
{
	if (nFATPos > FATSize())
	{
		return NULL;
	}
	else
	{
		return m_pFAT->GetFilename(nFATPos);
	}
}


/*************************
 FileExist

	determine if a file 
	exists in the pakfile.
 *************************/
bool CPakFile::FileExist(char* pstrFileToCheck)
{
	m_pFAT->SetFilePos(m_pFSH->m_fsh.nAbsoluteFAT);
	m_pFAT->Read();
	int r = m_pFAT->Find(pstrFileToCheck);
	if (r != -1)
	{
		return true;
	}
	else
	{
		return false;
	}
}


/*************************
 Add

 Add a file to the pakfile
 pstrFileToAdd- file to add
 pstrSaveAs- filename to 
 save as
 *************************/
void CPakFile::Add(char* pstrFileToAdd, char* pstrSaveAs)
{
	int nInsert = 0;
	//always adds to end right now.
	/*if (m_pFSH->m_fsh.nAbsoluteHole == -1)
	{*/
	//no holes -- add to location of FAT
	nInsert = m_pFSH->m_fsh.nAbsoluteFAT; //+ m_pFSH->m_fsh.nAbsoluteBeginning;
	FILE* f = fopen(pstrFileToAdd, "rb");
	if (f == NULL)
		return;

	fseek(f, 0, SEEK_END);
	int nFileLength = ftell(f);
	fseek(f, 0, SEEK_SET);

	//construct head...
	SEGHead sh;
	sh.cDeleted = 0;
	sh.nAbsolutePrev = -1;
	sh.nFileSize = nFileLength;
	sh.nSegSize = nFileLength;

	//write out head...
	fseek(m_file, nInsert, SEEK_SET);
	fwrite(&sh, sizeof(SEGHead), 1, m_file);

	//construct info...
	SEGFileInfo sfi;
	sfi.cCompression = 0;
	sfi.cEncryption = 0;
	sfi.nCopyright = 2001;
	strcpy(sfi.strAuthor, "");
	strcpy(sfi.strDescription, "");
	strcpy(sfi.strPassword, "");

	//write out info...
	fwrite(&sfi, sizeof(SEGFileInfo), 1, m_file);

	//write out filename...
	fwrite(pstrSaveAs, sizeof(char), strlen(pstrSaveAs)+1, m_file);

	//now write file...
	for (int i=0; i<nFileLength; i++) 
	{
		char in;
		fread(&in, sizeof(char), 1, f);
		fwrite(&in, sizeof(char), 1, m_file);
	}
	fclose(f);

	//construct tail...
	SEGFoot st;
	st.nAbsoluteNext = -1;

	//write out tail...
	fwrite(&st, sizeof(SEGFoot), 1, m_file);

	//re-align FAT...
	int fatpos = ftell(m_file);
	m_pFAT->SetFilePos(fatpos);

	//add file to FAT...
	m_pFAT->Add(pstrSaveAs, nInsert- m_pFSH->m_fsh.nAbsoluteBeginning);

	//write FAT...
	m_pFAT->Write();

	//write file header...
	m_pFSH->m_fsh.nAbsoluteFAT = fatpos;
	m_pFSH->m_fsh.nDataSize += nFileLength;
	m_pFSH->SetFilePos(m_pFSH->m_fsh.nAbsoluteBeginning);
	m_pFSH->Write();
	/*}*/

}


/*************************
 AddCompressed

 Add a file to the pakfile
 Compress it.
 pstrFileToAdd- file to add
 pstrSaveAs- filename to 
 save as
 nCompType- 0=huffman, 1=zlib
 *************************/
void CPakFile::AddCompressed(char* pstrFileToAdd, char* pstrSaveAs, int nCompType)
{
	int nInsert = 0;
	//always adds to end right now.
	/*if (m_pFSH->m_fsh.nAbsoluteHole == -1)
	{*/
	//no holes -- add to location of FAT
	nInsert = m_pFSH->m_fsh.nAbsoluteFAT; //+ m_pFSH->m_fsh.nAbsoluteBeginning;

	//first compress the file into a temp file...
	m_Huff->SetCompType(nCompType);
	m_Huff->Compress(pstrFileToAdd, "temp.tmp");

	FILE* f = fopen("temp.tmp", "rb");
	if (f == NULL)
		return;

	fseek(f, 0, SEEK_END);
	int nFileLength = ftell(f);
	fseek(f, 0, SEEK_SET);

	//construct head...
	SEGHead sh;
	sh.cDeleted = 0;
	sh.nAbsolutePrev = -1;
	sh.nFileSize = nFileLength;
	sh.nSegSize = nFileLength;

	//write out head...
	fseek(m_file, nInsert, SEEK_SET);
	fwrite(&sh, sizeof(SEGHead), 1, m_file);

	//construct info...
	SEGFileInfo sfi;
	if (nCompType==0)
		sfi.cCompression = 1;	//huffman compression!
	else
		sfi.cCompression = 2;	//zlib!
	sfi.cEncryption = 0;
	sfi.nCopyright = 2001;
	strcpy(sfi.strAuthor, "");
	strcpy(sfi.strDescription, "");
	strcpy(sfi.strPassword, "");

	//write out info...
	fwrite(&sfi, sizeof(SEGFileInfo), 1, m_file);

	//write out filename...
	fwrite(pstrSaveAs, sizeof(char), strlen(pstrSaveAs)+1, m_file);

	//now write file...
	for (int i=0; i<nFileLength; i++) 
	{
		char in;
		fread(&in, sizeof(char), 1, f);
		fwrite(&in, sizeof(char), 1, m_file);
	}
	fclose(f);

	//construct tail...
	SEGFoot st;
	st.nAbsoluteNext = -1;

	//write out tail...
	fwrite(&st, sizeof(SEGFoot), 1, m_file);

	//re-align FAT...
	int fatpos = ftell(m_file);
	m_pFAT->SetFilePos(fatpos);

	//add file to FAT...
	m_pFAT->Add(pstrSaveAs, nInsert - m_pFSH->m_fsh.nAbsoluteBeginning);

	//write FAT...
	m_pFAT->Write();

	//write file header...
	m_pFSH->m_fsh.nAbsoluteFAT = fatpos;
	m_pFSH->m_fsh.nDataSize += nFileLength;
	m_pFSH->SetFilePos(m_pFSH->m_fsh.nAbsoluteBeginning);
	m_pFSH->Write();

	//system("del temp.tmp");
	DeleteFile("temp.tmp");
}


/*************************
 Extract

 Extract a file from the pakfile
 pstrFileToExtract- file to extract
 pstrSaveAs- filename to 
 save as
 *************************/
void CPakFile::Extract(char* pstrFileToExtract, char* pstrSaveAs)
{
	int nFilePos = m_pFAT->Find(pstrFileToExtract);
	if (nFilePos != -1)
	{
		nFilePos += m_pFSH->m_fsh.nAbsoluteBeginning;
		fseek(m_file, nFilePos, SEEK_SET);

		SEGHead sh;
		//read header...
		fread(&sh, sizeof(SEGHead), 1, m_file);

		SEGFileInfo sfi;
		//read file info...
		fread(&sfi, sizeof(SEGFileInfo), 1, m_file);

		//read filename...
		char* filename = ReadString();

		if (sfi.cCompression == 1 || sfi.cCompression == 2)
		{
			//compression was used!
			//open export file for writing
			FILE* f = fopen("temp.tmp", "wb");

			for (int i=0; i<sh.nSegSize; i++)
			{
				char in;
				fread(&in, sizeof(char), 1, m_file);
				fwrite(&in, sizeof(char), 1, f);
			}
		
			//read footer...
			SEGFoot sf;
			fread(&sf, sizeof(SEGFoot), 1, m_file);
			
			if (sf.nAbsoluteNext == -1)
			{
				//eof
			}

			fclose(f);

			//now decompress temp file...
			m_Huff->SetCompType(sfi.cCompression);
			m_Huff->Decompress("temp.tmp", pstrSaveAs);
			//system("del temp.tmp");
			DeleteFile("temp.tmp");
		}
		else
		{
			//no compression.
			//open export file for writing
			FILE* f = fopen(pstrSaveAs, "wb");

			for (int i=0; i<sh.nSegSize; i++)
			{
				char in;
				fread(&in, sizeof(char), 1, m_file);
				fwrite(&in, sizeof(char), 1, f);
			}
		
			//read footer...
			SEGFoot sf;
			fread(&sf, sizeof(SEGFoot), 1, m_file);
			
			if (sf.nAbsoluteNext == -1)
			{
				//eof
			}

			fclose(f);
		}
	}
}


/*****************************
 CPakFile::Delete()

	Deletes a file from the system

 *****************************/
void CPakFile::Delete(char* pstrFileToDelete)
{
	int nFilePos = m_pFAT->Find(pstrFileToDelete);
	if (nFilePos != -1) 
	{
		//it exists!
		//delete it from the FAT...
		m_pFAT->Delete(pstrFileToDelete);

		//re-write FAT...
		m_pFAT->Write();

		//locate position of file...
		nFilePos += m_pFSH->m_fsh.nAbsoluteBeginning;

		bool bDone = false;
		while (!bDone)
		{
			fseek(m_file, nFilePos, SEEK_SET);

			SEGHead sh;
			//read header...
			fread(&sh, sizeof(SEGHead), 1, m_file);

			//mark file as deleted...
			sh.cDeleted = 1;

			//write header...
			fseek(m_file, nFilePos, SEEK_SET);
			fwrite(&sh, sizeof(SEGHead), 1, m_file);
			
			//now to link this hole with the next hole in the file...
			int segfoot = sh.nSegSize + nFilePos;

			fseek(m_file, segfoot, SEEK_SET);
			//read footer...
			SEGFoot sf;
			fread(&sf, sizeof(SEGFoot), 1, m_file);
			
			int oldNext = sf.nAbsoluteNext;
			sf.nAbsoluteNext = m_pFSH->m_fsh.nAbsoluteHole;
			m_pFSH->m_fsh.nAbsoluteHole = nFilePos;

			//write modified header and seg foot...
			m_pFSH->m_fsh.nDeletedSize += sh.nSegSize;
			m_pFSH->Write();
			fseek(m_file, segfoot, SEEK_SET);
			fwrite(&sf, sizeof(SEGFoot), 1, m_file);

			if (oldNext != -1)
			{
				//this file continues...
				nFilePos = oldNext;
			}
			else
			{
				bDone = true;
			}
		}
	}

}


/*****************************
 CPakFile::Defrag()

	fills holes.

	pstrSaveAs - file to save
	defragged pak file as.

 *****************************/
void CPakFile::Defrag(char* pstrSaveAs)
{
	//read FAT...
	m_pFAT->SetFilePos(m_pFSH->m_fsh.nAbsoluteBeginning + m_pFSH->m_fsh.nAbsoluteFAT);
	m_pFAT->Read();
	int num = m_pFAT->NumFiles();

	CPakFile newFile(pstrSaveAs, false);

	for (int i=0; i<num; i++)
	{
		char* file = m_pFAT->GetFilename(i);
		this->Extract(file, "temp.tmp");
		newFile.Add("temp.tmp", file);
	}
	//system("del temp.tmp");
	DeleteFile("temp.tmp");
}


/*****************************
 CPakFile::AddFromList

	opens a text file with a
	list of files to add.

	Then it adds them.

 *****************************/
void CPakFile::AddFromList(char* pstrListName)
{
	int fatpos = 0;
	int nFileLength = 0;
	char dummy[1024];
	FILE* lf = fopen(pstrListName, "rt");
	while (!feof(lf))
	{
		fgets(dummy, 1024, lf);
		int len = strlen(dummy);
		if (len-1 >=0) 
			if (dummy[len-1] == '\n') 
				dummy[len-1] = '\0';
		int nInsert = 0;
		//always adds to end right now.
		nInsert = m_pFSH->m_fsh.nAbsoluteFAT + m_pFSH->m_fsh.nAbsoluteBeginning;
		FILE* f = fopen(dummy, "rb");
		if (f == NULL)
			continue;

		fseek(f, 0, SEEK_END);
		nFileLength = ftell(f);
		fseek(f, 0, SEEK_SET);

		//construct head...
		SEGHead sh;
		sh.cDeleted = 0;
		sh.nAbsolutePrev = -1;
		sh.nFileSize = nFileLength;
		sh.nSegSize = nFileLength;

		//write out head...
		fseek(m_file, nInsert, SEEK_SET);
		fwrite(&sh, sizeof(SEGHead), 1, m_file);
		//write out filename...
		fwrite(dummy, sizeof(char), strlen(dummy)+1, m_file);

		//now write file...
		for (int i=0; i<nFileLength; i++) 
		{
			char in;
			fread(&in, sizeof(char), 1, f);
			fwrite(&in, sizeof(char), 1, m_file);
		}
		fclose(f);

		//construct tail...
		SEGFoot st;
		st.nAbsoluteNext = -1;

		//write out tail...
		fwrite(&st, sizeof(SEGFoot), 1, m_file);

		//re-align FAT...
		fatpos = ftell(m_file);
		m_pFAT->SetFilePos(fatpos);

		//add file to FAT...
		m_pFAT->Add(dummy, nInsert);
		m_pFSH->m_fsh.nAbsoluteFAT = fatpos;
		m_pFSH->m_fsh.nDataSize += nFileLength;
	}

	fclose(lf);

	//write FAT...
	m_pFAT->Write();

	//write file header...
	m_pFSH->m_fsh.nAbsoluteFAT = fatpos;
	m_pFSH->m_fsh.nDataSize += nFileLength;
	m_pFSH->SetFilePos(0);
	m_pFSH->Write();
}

/*****************************
 CPakFile::ReadString()

	Reads a null-terminated string 
	from the file.

 *****************************/
char* CPakFile::ReadString()
{
	char* strIn = new char[2048];
	char part;
	int n=0;
	bool bDone = false;
	while (!bDone)
	{
		fread(&part, sizeof(char), 1, m_file);
		if (part == 0)
		{
			//end of string encountered!
			strIn[n] = part;
			//int l = strlen(strIn);
			//pstrCopyTo = new char[l+1];
			//strcpy(pstrCopyTo, strIn);
			bDone = true;
		}
		else
		{
			strIn[n] = part;
			n++;
		}
	}
	return strIn;
}



/* end of file */