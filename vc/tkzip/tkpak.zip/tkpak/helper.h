//helper.h
//helper functions

#include <iostream.h>
#include <direct.h>
#include "CPakFile.h"

void AddFiles(CPakFile* cp, 
							char* pstrSearchParam, 
							char* pstrSourceDir, 
							bool bRecurse = true, 
							int nCompression = COMP_ZLIB);

void CreateDir(char* pstrPathName);

//////////////////////////////////
// AddFiles
//
// Add files in directory and subdir
//
// cp- pak file to add to.
// pstrSearchParam - wildcard, like *.*
// pstrSourceDir - just a dir that is tacked onto the front
//								of the file.
// bRecurse - recurse subdir?
// nCompression - compression type
void AddFiles(CPakFile* cp, 
							char* pstrSearchParam, 
							char* pstrSourceDir, 
							bool bRecurse, 
							int nCompression)
{
	WIN32_FIND_DATA fd;
	HANDLE hFindFile = FindFirstFile(pstrSearchParam, &fd);
	int nGood = 1;
	while (nGood)
	{
		if (nGood)
		{
			//check if it's a dir...
			if (fd.dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY)
			{
				if (bRecurse)
				{
					if (strcmp(fd.cFileName, ".") && strcmp(fd.cFileName, ".."))
					{
						char strCurDir[MAX_PATH];
						char strSource[MAX_PATH];
						getcwd(strCurDir, MAX_PATH);
						chdir(fd.cFileName);
						strcpy(strSource, fd.cFileName);
						strcat(strSource, "\\");
						AddFiles(cp, pstrSearchParam, strSource, bRecurse, nCompression);
						chdir(strCurDir);
					}
				}
			}
			else
			{
				if (strcmpi(fd.cFileName, cp->GetFileName()))
				{
					char strCurDir[MAX_PATH];
					strcpy(strCurDir, pstrSourceDir);
					strcat(strCurDir, fd.cFileName);
					cout << "Adding " << strCurDir << endl;
					if (nCompression == COMP_NONE)
						cp->Add(fd.cFileName, strCurDir);
					else
						cp->AddCompressed(fd.cFileName, strCurDir, nCompression);
				}
			}
		}
		nGood = FindNextFile(hFindFile, &fd);
	}
	FindClose(hFindFile);
}


//////////////////////////////////
// ExtractFiles
//
// Extract pakfile 
//
// cp- pak file
// pstrExpandDir - dir to expand into
void ExtractFiles(CPakFile* cp, char* pstrExpandDir)
{
	mkdir(pstrExpandDir);
	for (int i=0; i<cp->FATSize(); i++)
	{
		cout << "Extracting " << cp->GetFATName(i) << endl; 
		char strPath[MAX_PATH];
		strcpy(strPath, pstrExpandDir);
		strcat(strPath, cp->GetFATName(i));
		CreateDir(strPath);
		cp->Extract(cp->GetFATName(i), strPath);
	}
}

//////////////////////////////////
// CreateDir
//
// Create a directory, with all
// required subpaths
//
// pstrPathName - path to create
void CreateDir(char* pstrPathName)
{
	char strPath[MAX_PATH];
	int nLen = strlen(pstrPathName);
	for (int i=0; i< nLen; i++)
	{
		strPath[i] = pstrPathName[i];
		strPath[i+1]=0;
		if (strPath[i] == '\\' || strPath[i] == '/')
		{
			mkdir(strPath);
		}
	}
}
