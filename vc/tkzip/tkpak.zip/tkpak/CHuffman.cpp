/*************************
 CHuffman.cpp
	Implementation of Huffman
	compressor
 *************************/


#include "stdafx.h"
#include "CHuffman.h"
#include "zlib.h"		//zlib for zip compression (override huffman!)
#include <stdlib.h>

//flip a string...
void strflip(char* pstrSource)
{
	char temp[1024];
	strcpy(temp, "");

	int j=0;
	int l=strlen(pstrSource);
	for (int i=l-1; i>=0; i--) 
	{
		char p = pstrSource[i];
		temp[j] = p;
		temp[++j] = 0;
	}
	strcpy(pstrSource, temp);
}

/********************************************************************************/

CHuffNode::CHuffNode(char cASCII, int nCount, CHuffNode* p, CHuffNode* o, CHuffNode* z)
{
	parent = p;
	one = o;
	zero = z;
	if (one)
		one->parent = this;
	if (zero)
		zero->parent = this;
	m_cElement = cASCII;
	m_nCount = nCount;
}
	
CHuffNode::~CHuffNode()
{
	if (one)
		delete one;
	if (zero)
		delete zero;
}


//determine magnitude of the tree...
int CHuffNode::size()
{
	int s = m_nCount;
	if (one)
	{
		s+= one->size();
	}
	if (zero)
	{
		s+= zero->size();
	}
	return s;
}

/*********************************************************************************/


//c-tor
CHuffman::CHuffman()
{
	m_nCompType = 0;
	m_nNodeCount = 0;
}

//d-tor
CHuffman::~CHuffman()
{
	for (int i=0; i<m_nNodeCount; i++)
	{
		delete m_NodeArray[i];
	}
}


/*************************
 SetCompType

	set the compression type
	0-huffman
	1-zlib
 *************************/
void CHuffman::SetCompType(int nCompType)
{
	m_nCompType = nCompType;
}


/*************************
 Compress

	Compresses pstrInFile
	into pstrOutFile (.thf)
 *************************/
void CHuffman::Compress(char* pstrInFile, char* pstrOutFile)
{
	if (m_nCompType == 0)
	{
		//HUFFMAN compression
		//do the ASCII count on all the characters in the file...
		CountChars(pstrInFile);
		//build the huffman tree...
		BuildTree();
		WriteCompressedFile(pstrInFile, pstrOutFile);
	}
	else
	{
		//ZLIB compression (uses zlib.lib)
		FILE* f = fopen(pstrInFile, "rb");
		if (f)
		{
			fseek(f, 0, SEEK_END);
			int len = ftell(f);
			fseek(f, 0, SEEK_SET);

			unsigned char* theFile = new unsigned char[len*2];
			unsigned char* theCompressed = new unsigned char[len*2];

			if (theFile && theCompressed)
			{
				//read input file...
				fread(theFile, 1, len, f);
				fclose (f);
				
				unsigned long newSize = len*2;
				int res = compress(theCompressed, &newSize, theFile, len);

				//write compressed file...
				FILE* dest = fopen(pstrOutFile, "wb");
				if (dest)
				{
					//first output size of decompressed file...
					fwrite(&len, 1, sizeof(int), dest);
					//now write compressed data...
					fwrite(theCompressed, 1, newSize, dest);
					fclose (dest);
				}

				delete [] theFile;
				delete [] theCompressed;
			}
		}
	}
}


/*************************
 Decompress

	Decompresses pstrInFile
	into pstrOutFile (.thf)
 *************************/
void CHuffman::Decompress(char* pstrInFile, char* pstrOutFile)
{
	if (m_nCompType == 0)
	{
		//decompress HUFFMAN
		//input header info...
		int i=0;
		int nUnCompSize = 0;
		FILE* fout = fopen(pstrOutFile, "wb");
		FILE* fin = fopen(pstrInFile, "rb");
		if (!fout || !fin)
			return;

		int nCompSize =0;
		fseek(fin, 0, SEEK_END);
		nCompSize = ftell(fin);
		fseek(fin, 0, SEEK_SET);

		//input compressed header...
		char hdr[6];
		fread(hdr, 6, sizeof(char), fin);
		
		//input uncompressed size...
		fread(&nUnCompSize, 1, sizeof(int), fin);

		//input char counts...
		for (i=0; i<256; i++)
		{
			fread(&m_nASCIICount[i], 1, sizeof(int), fin);
		}

		//build huffman table...
		BuildTree();

		//now progressively decode the file...
		m_nBytesWritten = 0;
		strcpy(m_strEncode, "");
		m_nUncompSize = nUnCompSize;
		while (m_nBytesWritten < nUnCompSize)
		{
			unsigned char part;
			fread(&part, 1, sizeof(char), fin);
			WriteDecoded(part, fout);
		}


		fclose(fout);
		fclose(fin);
	}
	else
	{
		//decompress ZLIB
		FILE* f = fopen(pstrInFile, "rb");
		if (f)
		{
			fseek(f, 0, SEEK_END);
			int len = ftell(f);
			fseek(f, 0, SEEK_SET);
			len -= sizeof(int);

			//first, read the size of the file uncompressed...
			int nUnComp = 0;
			fread(&nUnComp, 1, sizeof(int), f);
			if (nUnComp>0)
			{
				unsigned char* theFile = new unsigned char[nUnComp+1];
				unsigned char* theCompressed = new unsigned char[len*2];

				//now read the compressed data...
				fread(theCompressed, 1, len, f);
				fclose (f);
			
				//now uncompress...
				unsigned long uncompSize = len*2;
				int res = uncompress (theFile, &uncompSize, theCompressed, len);

				//now write the result...
				f = fopen(pstrOutFile, "wb");
				if (f)
				{
					fwrite(theFile, 1, uncompSize, f);
					fclose (f);
				}				

				delete [] theFile;
				delete [] theCompressed;
			}
		}
	}
}


void CHuffman::CountChars(char* pstrInFile)
{
	int i=0;
	for (i=0; i<256; i++)
	{
		m_nASCIICount[i] = 0;
	}

	FILE* f = fopen(pstrInFile, "rb");
	if (f)
	{
		fseek(f, 0, SEEK_END);
		int l = ftell(f);
		fseek(f, 0, SEEK_SET);
		for (i=0; i<l; i++) 
		{
			unsigned char c;
			fread(&c, sizeof(char), 1, f);
			m_nASCIICount[c]++;
		}
		fclose(f);
	}
}


void CHuffman::BuildTree() 
{
	//copy ascii table over into huffman tree array...
	m_nNodeCount = 0;
	int i=0;
	for (i=0; i<256; i++)
	{
		if (m_nASCIICount[i] > 0)
		{
			//these characters exist!
			m_NodeArray[m_nNodeCount] = new CHuffNode(i, m_nASCIICount[i], NULL, NULL, NULL);
			m_nNodeCount++;
		} 
	}

	for (i=0; i<m_nNodeCount; i++)
	{
		m_LeafArray[i] = m_NodeArray[i];
	}
	m_nLeafCount = m_nNodeCount;


	while (m_nNodeCount > 1)
	{
		CombineSmallest();
	}

	int s = m_NodeArray[0]->size();
	
	//now fill encoding table...
	FillEncodingTable();
	int n = CalcCompressedSize();
}


//combine the smallest nodes into one in the node tree...
void CHuffman::CombineSmallest()
{
	if (m_nNodeCount <=1) return;
	int smallest = 0;
	int secondsmallest = 0;

	int i=0;

	//find smallest
	for (i=0; i<m_nNodeCount; i++)
	{
		if (m_NodeArray[i]->size() <= m_NodeArray[smallest]->size())
		{
			smallest = i;
		}
	}

	if (secondsmallest == 0 && smallest ==0)
		secondsmallest = 1;
	//find new second smallest...
	for (i=0; i<m_nNodeCount; i++)
	{
		if (i != smallest)
		{
			if (m_NodeArray[i]->size() <= m_NodeArray[secondsmallest]->size())
			{
				secondsmallest = i;
			}
		}
	}

	//now combine smallest and second smallest!
	CHuffNode* n = new CHuffNode(-1, 0, NULL, m_NodeArray[smallest], m_NodeArray[secondsmallest]);
	
	//re-organise array with new combined node.
	CHuffNode* tempArray[256];
	int j=0;
	for (i=0; i<m_nNodeCount; i++)
	{
		if (i != smallest && i != secondsmallest)
		{
			tempArray[j] = m_NodeArray[i];
			j++;
		}
	}
	tempArray[j] = n;
	j++;

	m_nNodeCount = j;
	for (i=0; i<m_nNodeCount; i++)
	{
		m_NodeArray[i] = tempArray[i];
	}
}


void CHuffman::FillEncodingTable()
{
	int i=0;
	for (i=0; i<256; i++)
	{
		strcpy(m_EncodingTable[i], "");
	}

	for (i=0; i<m_nLeafCount; i++) 
	{
		char temp[256];
		strcpy(temp, "");
		CHuffNode* p = m_LeafArray[i];
		unsigned char c = p->m_cElement;
		while (p)
		{
			if (p->parent)
			{
				if (p->parent->one == p)
				{
					strcat(temp, "1");
					p=p->parent;
				}
				else
				{
					strcat(temp, "0");
					p=p->parent;
				}
			}
			else
			{
				p = NULL;
			}
		}
		strflip(temp);
		strcpy(m_EncodingTable[c], temp);
	}
}

//return compressed size!
int CHuffman::CalcCompressedSize()
{
	int i;
	int size = 0;
	for (i=0; i<256; i++)
	{
		int bits = strlen(m_EncodingTable[i]);
		size += bits * m_nASCIICount[i];
	}
	size /= 8;
	return size;
}


//now that we have the tree and encodings calculated,
//let's output the compressed file!
void CHuffman::WriteCompressedFile(char* pstrInFile, char *pstrOutFile)
{
	int i=0;
	FILE* fout = fopen(pstrOutFile, "wb");
	FILE* fin = fopen(pstrInFile, "rb");
	if (!fout || !fin)
		return;

	fseek(fin, 0, SEEK_END);
	int nUnCompSize = ftell(fin);
	fseek(fin, 0, SEEK_SET);

	//output compressed header...
	char hdr[6];
	strcpy(hdr, "TKHUF");
	fwrite(hdr, strlen(hdr)+1, sizeof(char), fout);
	
	//output uncompressed size...
	fwrite(&nUnCompSize, 1, sizeof(int), fout);

	//output char counts...
	for (i=0; i<256; i++)
	{
		fwrite(&m_nASCIICount[i], 1, sizeof(int), fout);
	}

	//now read source file and output it encoded into the compressed file...
	//clear temporary encoding buffer...
	strcpy(m_strEncode, "");
	for (i=0; i<nUnCompSize; i++)
	{
		unsigned char part;
		fread(&part, 1, sizeof(char), fin);
		WriteEncoded(part, fout);
	}

	CloseCompressionStream(fout);
	fclose(fin);
}


//accept a character. look it up in the encoding table.
//write it to the file bit-encoded.
void CHuffman::WriteEncoded(unsigned char part, FILE* fout)
{
	//add this character to the output bits...
	strcat(m_strEncode, m_EncodingTable[part]);
	
	if (strlen(m_strEncode) >=8)
	{
		//we have a full byte to output!
		char theByte[10];
		//strip off first 8 chars...
		for (unsigned int j=0; j<8; j++)
		{
			theByte[j] = m_strEncode[j];
			theByte[j+1] = 0;
		}
		if (strlen(m_strEncode) == 8)
		{
			strcpy(m_strEncode, "");
		}
		else
		{
			unsigned int l = strlen(m_strEncode);
			for (j=8; j<l; j++)
			{
				m_strEncode[j-8] = m_strEncode[j];
				m_strEncode[j-7] = 0;
			}
		}
		unsigned char equivByte = BitsToByte(theByte);
		fwrite(&equivByte, 1, sizeof(char), fout);
	}
}


//accept an encoded (compressed) byte, look up contents in
//the encoding table, write it to decompressed file.
void CHuffman::WriteDecoded(unsigned char part, FILE* fout)
{
	char theByte[10];
	int ch;
	//convert to bits...
	ByteToBits(part, theByte);
	strcat(m_strEncode, theByte);
	
	ch = AttemptTreeDecode();
	while (ch != -1)
	{
		unsigned char c = (unsigned char)ch;
		fwrite(&c, 1, sizeof(char), fout);
		m_nBytesWritten++;
		if (m_nBytesWritten < m_nUncompSize)
			ch = AttemptTreeDecode();
		else
			break;
	}
}



//close the compressed file.
//pads final bits if necissary.
void CHuffman::CloseCompressionStream(FILE* fout)
{
	int remain = strlen(m_strEncode);
	if (remain == 0)
	{
		fclose (fout);
		return;
	}
	int toAdd = 8-remain;
	for (int i=0; i<toAdd; i++)
	{
		m_strEncode[remain+i] = 0;
		m_strEncode[remain+i+1] = 0;
	}
	unsigned char equivByte = BitsToByte(m_strEncode);
	fwrite(&equivByte, 1, sizeof(char), fout);
	fclose(fout);	
}

//convert a string of 8 bits into a byte...
unsigned char CHuffman::BitsToByte(char* theByte)
{
	int val = 0;
	for (int i=7; i>=0; i--)
	{
		char part = theByte[i];
		if (part == '1')
		{
			//a 1 is encountered!
			val += power(2, -i+7);
		}
	}
	return (unsigned char)val;
}


//convert a byte (part) to a bitstring (theByte)
void CHuffman::ByteToBits(unsigned char part, char* theByte)
{
	strcpy(theByte, "");
	for (int i=7; i>=0; i--)
	{
		unsigned char digit = part / power(2, i);
		part -= power(2, i) * digit;
		if (digit == 1)
			theByte[-i+7] = '1';
		else
			theByte[-i+7] = '0';
		theByte[-i+8] = 0;
	}
}


//using m_strEncode string, we will step
//thru the huffman tree.
//if we end up at a byte, we will adjust
//m_strEnocde and return the decoded char
//else we will return -1 (although we return an int, you
//should cast it to a uchar when you get it!
int CHuffman::AttemptTreeDecode()
{
	CHuffNode* p = m_NodeArray[0];
	bool done = false;
	unsigned int pos = 0;
	while (!done)
	{
		if (p->one == NULL && p->zero == NULL)
		{
			//we have reached a leaf!
			//so, we have actually found a value!
			
			//adjust the m_strEncode string...
			unsigned int j = strlen(m_strEncode);
			for (unsigned int i=pos; i<j; i++)
			{
				m_strEncode[i-pos] = m_strEncode[i];
				m_strEncode[i-pos+1] = 0;
			}
			return (unsigned char)p->m_cElement;

		}
		char part = m_strEncode[pos];
		if (part == '1')
		{
			p = p->one;
		}
		else
		{
			p = p->zero;
		}
		pos++;

		if (pos >= strlen(m_strEncode))
			done = true;
	}

	return -1;
}

//calculate exponent.
int CHuffman::power(int base, int exp)
{
	if (exp == 0)
		return 1;
	int val = 1;
	for (int i=0; i<exp; i++)
	{
		val *= base;
	}
	return val;
}