////////////////////////////////////////////////////////////////
//
// RPG Toolkit Development System, Version 3
// Fight System
// Developed by Christopher B. Matthews (Copyright 2003)
//
// This file is released under the AC Open License Derivative v 1.0
// See "AC Open License Derivative.txt"
//
////////////////////////////////////////////////////////////////
//////////////////////////////
// Fight.cpp - fighting system

#include "stdafx.h"
#include "fight.h"

#include <queue>
#include <time.h>

CNVID g_cnvBkg = 0;		//canvas the background image is on

int g_nEnemyCount = 0;	//number of enemies
bool g_bCanRun;		//can run from enemy?

std::queue<FIGHTER> g_qCharged;	//queue of fighters who are charged...

//info for the current player who is doing their move...
bool g_bPlayerMoving = false;	//is any player currently showing a menu?

FIGHTER g_CurrentFighter;	//the current fighter moving...
int g_nPartyWon = -1;			//which party has won



//Add a fighter to the charge queue.
//this ia s list of fighters who are chargd up
//and who can now do moves...
void QueueFighter( FIGHTER fighter )
{
	g_qCharged.push( fighter );
}


//pop the next fighter from the front of the queue
bool NextFighter( FIGHTER* p_fighter ) 
{
	if ( g_qCharged.size() > 0 ) 
	{
		*p_fighter = g_qCharged.front();
		//now remove the event at the head of the list...
		g_qCharged.pop();
		return true;
	}
	else 
	{
		return false;
	}	
}


//begin fighting...
int BeginFight( int nEnemyCount, int nSkillLevel, std::string strBackground, bool bCanRun )
{
	int nRet = FIGHT_WON_AUTO;
	g_nPartyWon = -1;

	//declare that I want keyboard input...
	RequestInputNotification( INPUT_KB );

	g_nEnemyCount = nEnemyCount;
	g_bCanRun = bCanRun;

	//clear old fight events
	FlushFightEvents();

	//create background canvas...
	g_cnvBkg = CBCreateCanvas( 640, 480 );

	//load fight background...
	CBCanvasDrawBackground( g_cnvBkg, strBackground, 0, 0, 640, 480 );

	//MAIN EVENT LOOP!!!
	//show scene...
	bool bDone = false;
	while( !bDone )
	{
		renderNow();
		CBFightTick();
		if ( !g_bPlayerMoving ) 
		{
			//no one is doing any moves...
			//so let's see if another player is charged...
			if ( NextFighter( &g_CurrentFighter ) ) 
			{
				g_bPlayerMoving = true;
				FlushInputEvents();
			}
		}
		int nResult = ScanKeys();
		if ( nResult == 1 )
		{
			//players ran...
			nRet = FIGHT_RUN_AUTO;
			bDone = true;

		}
		//check for end of fight...
		if ( g_nPartyWon == PLAYER_PARTY )
		{
			nRet = FIGHT_WON_AUTO;
			bDone = true;
		}
		if ( g_nPartyWon == ENEMY_PARTY )
		{
			nRet = FIGHT_LOST;
			bDone = true;
		}

		//for testing purposes-- hit Q to leave the fight...
		if (CBCheckKey("Q"))
		{
			bDone = true;
		}
	}

	//kill bkg canvas...
	CBDestroyCanvas( g_cnvBkg );

	CancelInputNotification( INPUT_KB );

	return nRet;	//players won
}


//render the scene...
//if bRefreshNow is true, then flip the scene forward
void renderNow()
{
	//draw the background...
	CBDrawCanvas( g_cnvBkg, 0, 0 );

	FIGHT_EVENT event;
	while ( GetNextFightEvent( &event ) ) 
	{
		RenderEvent( event );
	}

	RenderEnemies();
	RenderPlayers();

	RenderMenu();

	CBRefreshScreen();
}


//draw the enemies onto the scene
void RenderEnemies() 
{
	//TODO: Show enemies
}

//draw the players onto the scene
void RenderPlayers() 
{
	//TODO: show players
}


//render fight menu
void RenderMenu()
{
	//TODO: show fight menu
}

//do the animation for a fighter
void AnimateFighter( FIGHTER fighter, std::string strAnimation, FIGHTER target )
{
	//TODO: animate a fighter
}


//render an event onscreen...
void RenderEvent( FIGHT_EVENT event ) 
{
	//determine the type of the event...
	switch( event.nCode ) 
	{
		case INFORM_SOURCE_ATTACK:
			AnimateFighter( event.source, "ATTACK", event.target );
			if (event.nTargetHP > 0 || event.nTargetSMP > 0)
			{
				//I'd have to write function to animate a fighter...

				AnimateFighter( event.target, "DEFEND", event.target );
			}
			if ( CBGetFighterHP( event.target.nPartyIdx, event.target.nFighterIdx ) <= 0 )
			{
				AnimateFighter( event.target, "DIE", event.target );		
			}
			//TODO: show the hp removed/added
			//pause...
			Sleep( 950 );
			break;

		case INFORM_SOURCE_ITEM:
			//show event.source using an item on event.target
			break;

		case INFORM_SOURCE_SMP:
			//show event.source using a special move on event.target
			break;

		case INFORM_SOURCE_CHARGED:
			//show that the event.source fighter has charged and is 
			//ready for battle.
			//I suggest that you add player charged events to a queue
			//that you can use later on to allow a player to move...

			//someone is charged up
			//if it's a player, we'll have to let the player 
			//do their move...
			if ( event.source.nPartyIdx == PLAYER_PARTY ) 
			{
				//I'd write this function somewhere, then
				//check the queue in the main event loop
				//to see if I should allow a player to make a move.
				QueueFighter( event.source );
			}
			break;
			
		case INFORM_SOURCE_PARTY_DEFEATED:
			//a party has been defeated	
			//I'd keep the winning party in a global var
			//to be checked in the main loop to see if the battle is 
			//over...
			if ( event.source.nPartyIdx == PLAYER_PARTY )
				g_nPartyWon = ENEMY_PARTY;
			else
				g_nPartyWon = PLAYER_PARTY;
	}
}


//scan keys for input...
int ScanKeys()
{
	INPUT_EVENT ie;
	ie.strKey = "";
	GetNextInputEvent( &ie );

	if ( ie.strKey.compare("UP") == 0 || CBCheckKey("JOYUP") )
	{
		//do something...
	}

	//eventually, you'll determine if the player has chosen to attack am enemy by displaying
	//menus.

	//Then you can use CBAttackFighter to carry out the attack
	return 0;
}
