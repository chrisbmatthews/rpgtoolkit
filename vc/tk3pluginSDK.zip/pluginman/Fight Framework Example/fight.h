////////////////////////////////////////////////////////////////
//
// RPG Toolkit Development System, Version 3
// Fight System
// Developed by Christopher B. Matthews (Copyright 2003)
//
// This file is released under the AC Open License Derivative v 1.0
// See "AC Open License Derivative.txt"
//
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////
// fight.h -- header file for main fight entries

#include "sdk\tkplugin.h"

#ifndef FIGHT_H
#define FIGHT_H

int BeginFight( int nEnemyCount, int nSkillLevel, std::string strBackground, bool bCanRun );

void QueueFighter( FIGHTER fighter );

bool NextFighter( FIGHTER* p_fighter ) ;

void renderNow();

void RenderEvent( FIGHT_EVENT event );

void RenderMenu();

void AnimateFighter( FIGHTER fighter, std::string strAnimation, FIGHTER target );

void RenderPlayers();

void RenderEnemies();

int ScanKeys();
#endif