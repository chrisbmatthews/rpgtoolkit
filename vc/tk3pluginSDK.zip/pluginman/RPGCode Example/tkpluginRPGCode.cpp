////////////////////////////////////////////////////////////////
//
// YOU SHOULD MODIFY THIS FILE!!!!
//
////////////////////////////////////////////////////////////////
//
// RPG Toolkit Development System, Version 3
// Plugin Libraries
// Developed by Christopher B. Matthews (Copyright 2003)
//
// This file is released under the AC Open License v 1.0
// See "AC Open License.txt"
//
////////////////////////////////////////////////////////////////
//
// File:					tkpluginRPGCode.cpp
// Includes:			tkplugin.h
//								stdafx.h
// Description:		This file defines a few required exported 
//								functions if the plugin will define new RPGCode.
//								You should edit these functions
//								to cause your plugin to actually do something
//								useful.
//
////////////////////////////////////////////////////////////////

/*
 * Includes
 */

#include "stdafx.h"
#include "sdk\tkplugin.h"
#include <string>


/*********************************************************************/
///////////////////////////////////////////////////////
// RPGCODE INTERFACE
//
// If this is an RPGCode plugin, you must modify
// TKPlugQuery
// TKPlugExecute
///////////////////////////////////////////////////////

///////////////////////////////////////////////////////
//
// Function: TKPlugQuery
//
// Parameters: pstrQuery - string passed in.
//
// Action: passes in an rpgcode command name.
//				this function is supposed to indicate
//				if it does or does not support this command
//
// Returns: 1 (if we can support the command)
//					0 (if we cannot support the command)
//
///////////////////////////////////////////////////////
int APIENTRY TKPlugQuery(char* pstrQuery)
{
	std::string strQuery = pstrQuery;
	if ( strQuery.compare( "yesnobox" ) == 0 ) 
	{
		//we support this command
		return 1;
	}

	//if we make it here, we don't support this command.
	return 0;
}


///////////////////////////////////////////////////////
//
// Function: TKPlugExecute
//
// Parameters: pstrCommand - command to execute
//
// Action: passes in an rpgcode command.
//				it is up to the plugin to execute
//				this command.
//
// Returns: 1 (command executed OK)
//					0 (error executing command)
//
///////////////////////////////////////////////////////
int APIENTRY TKPlugExecute(char* pstrCommand)
{
	int nRet = 0;
	std::string strCmdName = CBGetCommandName( pstrCommand );
	if ( strCmdName.compare( "yesnobox" ) ==0 ) 
	{
		//get the contents of the brackets...
		std::string strBracket = CBGetBrackets( pstrCommand );

		//count the number of elements in the brackets...
		int num = CBCountBracketElements( strBracket );
		
		if ( num != 2 )
		{
			//there should be 2 elements!
			CBDebugMessage( "Error: #YesNoBox required 2 data elements!" );
			//let's bail!
			return 1;
		}

		//ok, get the two elements from the brackets...
		std::string strE1 = CBGetBracketElement( strBracket, 1 );
		std::string strE2 = CBGetBracketElement( strBracket, 2 );

		//now check the types of these elements (should be lit then num)...
		int nE1Type = CBGetElementType( strE1 );
		int nE2Type = CBGetElementType( strE2 );
		if ( nE1Type != 1 || nE2Type != 0) 
		{
			//if we get in here, then improper types were passed in...
			CBDebugMessage( "Error: #YesNoBox data types should be lit, num!" );
			//let's bail!
			return 1;
		}

		//ok, if we made it here, all's well.
		//let's do what we were supposed to do...
			
		//first, get the text value (the question...)
		std::string strTxt = CBGetStringElementValue( strE1 );

		int nRes = MessageBox( NULL, strTxt.c_str(), "", MB_YESNO );

		if ( nRes == IDYES )
		{
			//the user selected Yes
			//put '1' (yes) into the dest variable...
			//remember that e2 was the 2nd element that we obtained
			//from the brackets.  it is the varibale we must set.
			CBSetNumerical( strE2, 1 );
		}
		else 
		{
			//the user selected No
			//put '0' (no) into the dest variable...
			CBSetNumerical( strE2, 0 );
		}

		nRet = 1;
	}
	return nRet;
}


